import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  const ApiException(this.message, [this.statusCode = 0]);
  final String message;
  final int statusCode;
  @override
  String toString() => message;
}

/// WordPress Application Passwords are supplied *only* over TLS.
/// http.Request.followRedirects=false prevents forwarding secrets across hosts.
class WooSuiteApi {
  WooSuiteApi({required this.site, required this.username, required this.appPassword, http.Client? client})
      : _client = client ?? http.Client();
  final Uri site;
  final String username;
  final String appPassword;
  final http.Client _client;

  static Uri parseSite(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty || uri.userInfo.isNotEmpty ||
        uri.hasQuery || uri.hasFragment || (uri.port != 443 && uri.hasPort)) {
      throw const ApiException('نشانی سایت باید HTTPS معتبر و بدون مشخصات ورود باشد.');
    }
    return uri.replace(path: uri.path.replaceAll(RegExp(r'/+$'), ''), query: null, fragment: null);
  }

  Uri endpoint(String route, [Map<String, String>? query]) {
    if (!RegExp(r'^[a-z0-9/_-]+$').hasMatch(route) || route.startsWith('/')) {
      throw const ApiException('مسیر API نامعتبر است.');
    }
    final base = site.path.endsWith('/') ? site.path.substring(0, site.path.length - 1) : site.path;
    return site.replace(path: '$base/wp-json/ab-woosuite/v1/$route', queryParameters: query);
  }

  Future<Map<String, dynamic>> get(String route, [Map<String, String>? query]) => _request('GET', route, query: query);
  Future<Map<String, dynamic>> post(String route, Map<String, Object?> data) => _request('POST', route, data: data);
  Future<Map<String, dynamic>> put(String route, Map<String, Object?> data) => _request('PUT', route, data: data);

  Future<Map<String, dynamic>> _request(String method, String route,
      {Map<String, String>? query, Map<String, Object?>? data}) async {
    final uri = endpoint(route, query);
    final request = http.Request(method, uri)
      ..followRedirects = false
      ..headers['Accept'] = 'application/json'
      ..headers['Authorization'] = 'Basic ${base64Encode(utf8.encode('$username:$appPassword'))}'
      ..headers['Cache-Control'] = 'no-store';
    if (data != null) {
      request.headers['Content-Type'] = 'application/json; charset=utf-8';
      request.body = jsonEncode(data);
    }
    http.StreamedResponse response;
    try {
      response = await _client.send(request).timeout(const Duration(seconds: 18));
    } catch (_) {
      throw const ApiException('ارتباط امن با سرور برقرار نشد. اینترنت و نشانی سایت را بررسی کنید.');
    }
    const maxBytes = 2 * 1024 * 1024;
    if (response.contentLength != null && response.contentLength! > maxBytes) {
      throw const ApiException('پاسخ سرور بیش از اندازه بزرگ است.');
    }
    final buffer = BytesBuilder(copy: false);
    await for (final chunk in response.stream) {
      if (buffer.length + chunk.length > maxBytes) {
        throw const ApiException('پاسخ سرور بیش از اندازه بزرگ است.');
      }
      buffer.add(chunk);
    }
    final bytes = buffer.takeBytes();
    Map<String, dynamic> body;
    try {
      final decoded = jsonDecode(utf8.decode(bytes));
      if (decoded is! Map<String, dynamic>) throw const FormatException();
      body = decoded;
    } catch (_) {
      throw ApiException('پاسخ دریافتی JSON معتبر نیست (HTTP ${response.statusCode}).', response.statusCode);
    }
    if (response.statusCode >= 300 || response.statusCode < 200) {
      final message = body['message'] is String ? body['message'] as String : 'خطای سرور';
      throw ApiException('$message (HTTP ${response.statusCode})', response.statusCode);
    }
    return body;
  }

  void dispose() => _client.close();
}
