import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_client.dart';

class SessionStore {
  SessionStore({FlutterSecureStorage? storage}) : _storage = storage ?? const FlutterSecureStorage();
  final FlutterSecureStorage _storage;

  Future<WooSuiteApi?> restore() async {
    final values = await Future.wait([
      _storage.read(key: 'ab_site'), _storage.read(key: 'ab_user'), _storage.read(key: 'ab_app_password'),
    ]);
    if (values.any((value) => value == null || value.isEmpty)) return null;
    try {
      return WooSuiteApi(site: WooSuiteApi.parseSite(values[0]!), username: values[1]!, appPassword: values[2]!);
    } catch (_) {
      await clear();
      return null;
    }
  }

  Future<void> save(WooSuiteApi api) async {
    await _storage.write(key: 'ab_site', value: api.site.toString());
    await _storage.write(key: 'ab_user', value: api.username);
    await _storage.write(key: 'ab_app_password', value: api.appPassword);
  }

  Future<void> clear() async {
    await _storage.delete(key: 'ab_site');
    await _storage.delete(key: 'ab_user');
    await _storage.delete(key: 'ab_app_password');
  }
}
