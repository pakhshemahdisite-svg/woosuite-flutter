import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onConnected});
  final Future<void> Function(WooSuiteApi api) onConnected;
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _site = TextEditingController();
  final _user = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _connect() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    WooSuiteApi? api;
    try {
      final uri = WooSuiteApi.parseSite(_site.text);
      if (_user.text.trim().isEmpty || _password.text.trim().isEmpty) {
        throw const ApiException('نام کاربری و Application Password ضروری هستند.');
      }
      api = WooSuiteApi(site: uri, username: _user.text.trim(), appPassword: _password.text.trim());
      final bootstrap = await api.get('mobile/bootstrap');
      if (bootstrap['api_version'] != 'v1') throw const ApiException('نسخه API سایت سازگار نیست.');
      await widget.onConnected(api);
    } catch (e) {
      api?.dispose();
      if (mounted) setState(() => _error = e is ApiException ? e.message : 'خطا در ذخیره نشست.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() { _site.dispose(); _user.dispose(); _password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Center(child: Container(width: 66, height: 66, decoration: BoxDecoration(color: ABTheme.black, borderRadius: BorderRadius.circular(22)),
            child: const Icon(Icons.dashboard_customize_rounded, color: ABTheme.gold, size: 32))),
          const SizedBox(height: 20),
          const Text('WooSuite Pro', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('مدیریت فروشگاه، همیشه همراه شما', textAlign: TextAlign.center, style: TextStyle(color: ABTheme.quiet)),
          const SizedBox(height: 28),
          ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('اتصال امن فروشگاه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            TextField(controller: _site, keyboardType: TextInputType.url, textDirection: TextDirection.ltr,
              autocorrect: false, decoration: const InputDecoration(labelText: 'نشانی HTTPS سایت', hintText: 'https://example.com')),
            const SizedBox(height: 13),
            TextField(controller: _user, autocorrect: false, decoration: const InputDecoration(labelText: 'نام کاربری مدیر')),
            const SizedBox(height: 13),
            TextField(controller: _password, obscureText: true, enableSuggestions: false, autocorrect: false,
              decoration: const InputDecoration(labelText: 'WordPress Application Password')),
            const SizedBox(height: 16),
            if (_error != null) ...[
              Text(_error!, style: const TextStyle(color: Color(0xFFB42318))), const SizedBox(height: 12),
            ],
            FilledButton.icon(onPressed: _busy ? null : _connect,
              icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.lock_outline),
              label: Text(_busy ? 'بررسی اتصال…' : 'اتصال به فروشگاه')),
          ])),
          const SizedBox(height: 16),
          const Text('از مسیر کاربران ← پروفایل ← Application Passwords یک رمز مخصوص اپ بسازید. رمز اصلی وردپرس را وارد نکنید. برای هر دستگاه رمز جداگانه استفاده کنید.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.8, color: ABTheme.quiet)),
        ],
      ))))),
  );
}
