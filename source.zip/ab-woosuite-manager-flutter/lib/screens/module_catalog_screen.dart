import 'package:flutter/material.dart';
import '../core/api_client.dart';
import '../theme.dart';

/// Informational portfolio; never attempts to install, sell or activate modules.
class ModuleCatalogScreen extends StatefulWidget {
  const ModuleCatalogScreen({super.key, required this.api});
  final WooSuiteApi api;

  @override
  State<ModuleCatalogScreen> createState() => _ModuleCatalogScreenState();
}

class _ModuleCatalogScreenState extends State<ModuleCatalogScreen> {
  late Future<Map<String, dynamic>> _catalog;

  @override
  void initState() {
    super.initState();
    _catalog = widget.api.get('modules/catalog');
  }

  void _refresh() => setState(() => _catalog = widget.api.get('modules/catalog'));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مرکز ماژول‌ها'), actions: [
      IconButton(tooltip: 'بروزرسانی', icon: const Icon(Icons.refresh), onPressed: _refresh),
    ]),
    body: FutureBuilder<Map<String, dynamic>>(
      future: _catalog,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          if (snapshot.hasError) return Center(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('دریافت ماژول‌ها ناموفق بود: ${snapshot.error}', textAlign: TextAlign.center),
          ));
          return const Center(child: CircularProgressIndicator());
        }
        final raw = snapshot.data!['items'];
        final items = raw is List ? raw.whereType<Map>().toList() : <Map>[];
        return RefreshIndicator(
          onRefresh: () async { _refresh(); await _catalog; },
          child: ListView(padding: const EdgeInsets.all(16), children: [
            const ABHeading('محصولات WooSuite', subtitle: 'وضعیت نصب و نقشه راه افزونه‌های مستقل'),
            const SizedBox(height: 12),
            for (final item in items) _module(item),
            const SizedBox(height: 14),
            ABPanel(child: Text('${snapshot.data!['note'] ?? ''}',
              style: const TextStyle(fontSize: 12, color: ABTheme.quiet, height: 1.8))),
          ]),
        );
      },
    ),
  );

  Widget _module(Map item) {
    final state = '${item['state'] ?? ''}';
    final stateText = switch (state) {
      'active' => 'فعال',
      'inactive' => 'نصب شده / غیرفعال',
      'missing' => 'نصب نشده',
      _ => 'در نقشه راه',
    };
    final isActive = state == 'active';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(isActive ? Icons.check_circle_rounded : Icons.widgets_outlined,
            color: isActive ? ABTheme.gold : ABTheme.quiet),
          const SizedBox(width: 10),
          Expanded(child: Text('${item['name'] ?? ''}',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          Text(stateText, style: const TextStyle(fontSize: 11, color: ABTheme.quiet)),
        ]),
        const SizedBox(height: 9),
        Text('${item['description'] ?? ''}',
          style: const TextStyle(fontSize: 13, color: ABTheme.quiet, height: 1.7)),
        if ('${item['version'] ?? ''}'.isNotEmpty) ...[
          const SizedBox(height: 9),
          Text('نسخه ${item['version']}', style: const TextStyle(fontSize: 11, color: ABTheme.quiet)),
        ],
      ])),
    );
  }
}
