import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/api_client.dart';
import '../theme.dart';
import 'module_catalog_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.api, required this.onLogout});
  final WooSuiteApi api;
  final Future<void> Function() onLogout;
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  int _page = 1;
  String _search = '';
  String _orderStatus = 'all';
  late Future<Map<String, dynamic>> _data;
  final _query = TextEditingController();
  Map<String, dynamic>? _answer;
  bool _asking = false;
  bool _aiAsking = false;
  Map<String, dynamic>? _aiAnswer;
  bool? _aiConnected;
  bool _planning = false;
  String _planGoal = 'overview';
  Map<String, dynamic>? _plan;

  final _titles = ['داشبورد', 'سفارش‌ها', 'محصولات', 'دستیار', 'اعلان‌ها'];
  static const _bottomLabels = ['خانه','سفارش','کالا','دستیار','اعلان'];
  static const _icons = [Icons.space_dashboard_rounded, Icons.receipt_long_rounded,
    Icons.inventory_2_outlined, Icons.auto_awesome_rounded, Icons.notifications_none_rounded];

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _query.dispose(); super.dispose(); }

  void _load() {
    final routes = ['dashboard', 'orders', 'products', 'mobile/briefing', 'notifications'];
    final params = <String, String>{};
    if (_tab == 1) { params['page'] = '$_page'; params['per_page'] = '15'; params['status'] = _orderStatus; }
    if (_tab == 2) { params['page'] = '$_page'; params['per_page'] = '15'; if (_search.isNotEmpty) params['search'] = _search; }
    setState(() => _data = widget.api.get(routes[_tab], params.isEmpty ? null : params));
  }

  void _navigate(int index) {
    if (_tab == index) return;
    _tab = index;
    _page = 1;
    _load();
  }

  String _num(Object? value) {
    final n = num.tryParse('$value');
    if (n == null) return '$value';
    return NumberFormat.decimalPattern('fa').format(n);
  }

  void _error(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      toolbarHeight: 72,
      title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('WOOSUITE / PRO', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: ABTheme.gold, letterSpacing: 1.2)),
        const SizedBox(height: 4),
        Text(_titles[_tab], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      ]),
      actions: [
        IconButton(tooltip: 'بروزرسانی', onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
        PopupMenuButton<String>(tooltip: 'حساب کاربری', icon: const Icon(Icons.account_circle_outlined),
          onSelected: (v) { if (v == 'logout') widget.onLogout(); },
          itemBuilder: (_) => [const PopupMenuItem(value: 'logout', child: Text('خروج و پاک‌کردن اطلاعات ورود'))]),
      ],
    ),
    body: SafeArea(child: FutureBuilder<Map<String, dynamic>>(
      future: _data,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _errorView(snapshot.error!);
        return RefreshIndicator(onRefresh: () async { _load(); await _data; },
          child: _content(snapshot.data ?? const {}));
      },
    )),
    bottomNavigationBar: NavigationBar(
      height: 76,
      selectedIndex: _tab,
      indicatorColor: ABTheme.gold.withOpacity(.16),
      onDestinationSelected: _navigate,
      destinations: List.generate(_titles.length, (i) => NavigationDestination(
        icon: Icon(_icons[i], size: 23), label: _bottomLabels[i])),
    ),
  );

  Widget _errorView(Object error) => Center(child: Padding(
    padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.wifi_off_rounded, size: 38, color: ABTheme.quiet), const SizedBox(height: 16),
      Text('$error', textAlign: TextAlign.center, style: const TextStyle(height: 1.8)),
      const SizedBox(height: 14), OutlinedButton(onPressed: _load, child: const Text('تلاش دوباره')),
    ]),
  ));

  Widget _content(Map<String, dynamic> data) {
    final view = switch (_tab) {0 => _dashboard(data), 1 => _orders(data),
      2 => _products(data), 3 => _assistant(data), _ => _notifications(data)};
    return ListView(padding: const EdgeInsets.fromLTRB(16, 7, 16, 24), children: [
      ConstrainedBox(constraints: const BoxConstraints(maxWidth: 860),
        child: view),
    ]);
  }

  Widget _dashboard(Map<String, dynamic> data) {
    final m = data['metrics'] is Map ? data['metrics'] as Map : <String, dynamic>{};
    final currency = '${data['currency'] ?? ''}';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const ABHeading('نبض فروشگاه', subtitle: 'نمای سریع وضعیت فروش، سفارش‌ها و انبار شما'),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: ABTheme.black, borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('فروش ۳۰ سفارش اخیر', style: TextStyle(color: Color(0xFFCAC7BD), fontSize: 13)),
          const SizedBox(height: 12),
          Text('${_num(m['sample_revenue'] ?? 0)} $currency',
            style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          const Text('مبلغ نمونه سفارش‌های موفق؛ نه سود خالص یا فروش کل',
            style: TextStyle(color: Color(0xFFADADAA), fontSize: 11)),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _metric('محصولات', _num(m['published_products'] ?? 0), Icons.inventory_2_outlined)),
        const SizedBox(width: 10),
        Expanded(child: _metric('سفارش‌های باز در نمونه', _num(m['pending_in_sample'] ?? 0), Icons.pending_actions_outlined)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _metric('سفارش بررسی‌شده', _num(m['sample_orders'] ?? 0), Icons.receipt_outlined)),
        const SizedBox(width: 10),
        Expanded(child: _metric('کمبود موجودی در نمونه', _num(m['low_stock_in_sample'] ?? 0), Icons.warning_amber_rounded)),
      ]),
      const SizedBox(height: 20),
      ABPanel(child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.widgets_outlined, color: ABTheme.gold),
        title: const Text('مرکز ماژول‌ها', style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('بررسی اتصال افزونه‌های مستقل و نقشه راه'),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => ModuleCatalogScreen(api: widget.api))),
      )),
      const SizedBox(height: 8),
      _section('آخرین سفارش‌ها'),
      ..._list(data['orders']).take(5).map((o) => ABPanel(child: Row(children: [
        const Icon(Icons.shopping_bag_outlined, color: ABTheme.gold), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('سفارش #${o['number']}', style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('${o['status_label'] ?? o['status']} · ${o['date'] ?? ''}', style: const TextStyle(fontSize: 12, color: ABTheme.quiet)),
        ])),
        Text(_num(o['total']), style: const TextStyle(fontWeight: FontWeight.w800)),
      ]))),
      const SizedBox(height: 12),
      _section('اقدامات پیشنهادی'),
      ..._list(data['insights']).map((insight) => ABPanel(child: ListTile(
        contentPadding: EdgeInsets.zero,
        title: Text('${insight['title']}', style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${insight['body']}', style: const TextStyle(height: 1.6)),
        leading: const Icon(Icons.tips_and_updates_outlined, color: ABTheme.gold),
      ))),
    ]);
  }

  Widget _metric(String title, String value, IconData icon) => ABPanel(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: ABTheme.gold), const SizedBox(height: 11),
      Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
      Text(title, style: const TextStyle(fontSize: 11, color: ABTheme.quiet)),
    ],
  ));

  Widget _orders(Map<String, dynamic> data) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const ABHeading('مرکز سفارش‌ها', subtitle: 'مدیریت سریع وضعیت سفارش‌های مجاز'),
    DropdownButtonFormField<String>(value: _orderStatus,
      items: const [
        DropdownMenuItem(value: 'all', child: Text('همه وضعیت‌ها')),
        DropdownMenuItem(value: 'on-hold', child: Text('در انتظار بررسی')),
        DropdownMenuItem(value: 'processing', child: Text('در حال انجام')),
        DropdownMenuItem(value: 'completed', child: Text('تکمیل‌شده')),
        DropdownMenuItem(value: 'pending', child: Text('در انتظار پرداخت')),
      ],
      onChanged: (value) { if (value != null) { _orderStatus = value; _page = 1; _load(); } }),
    const SizedBox(height: 12),
    if (_list(data['items']).isEmpty) const ABPanel(child: Text('سفارشی برای این فیلتر وجود ندارد.')),
    ..._list(data['items']).map((o) => ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text('سفارش #${o['number']}',
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
        _chip('${o['status_label'] ?? o['status']}')]),
      const SizedBox(height: 8),
      Text('${_num(o['total'])} ${o['currency'] ?? ''} · ${o['date'] ?? ''}',
        style: const TextStyle(color: ABTheme.quiet)),
      if (o['can_edit'] == true && ['on-hold', 'processing'].contains('${o['status']}')) ...[
        const SizedBox(height: 8),
        TextButton.icon(onPressed: () => _changeOrder(o), icon: const Icon(Icons.swap_horiz_rounded),
          label: const Text('تغییر وضعیت با تأیید')),
      ],
    ]))),
    _pager(data),
  ]);

  Future<void> _changeOrder(Map<String, dynamic> order) async {
    final status = '${order['status']}';
    final candidates = status == 'on-hold' ? ['processing'] : ['on-hold', 'completed'];
    final selected = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: Text('تغییر وضعیت سفارش #${order['number']}'),
      content: const Text('تغییر وضعیت ممکن است ایمیل‌های ووکامرس را ارسال کند. این عملیات ثبت می‌شود.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
        for (final value in candidates) TextButton(onPressed: () => Navigator.pop(context, value),
          child: Text(value == 'processing' ? 'در حال انجام' : value == 'completed' ? 'تکمیل‌شده' : 'در انتظار بررسی'))],
    ));
    if (selected == null) return;
    try {
      await widget.api.put('orders/${order['id']}/status', {'status': selected, 'expected_status': status});
      if (!mounted) return;
      _load();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('وضعیت سفارش ثبت شد.')));
    } catch (e) { _error(e); }
  }

  Widget _products(Map<String, dynamic> data) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const ABHeading('کاتالوگ محصولات', subtitle: 'جست‌وجو، قیمت، موجودی و تنوع‌ها'),
    TextField(decoration: InputDecoration(hintText: 'جست‌وجوی نام یا کد کالا',
      suffixIcon: IconButton(onPressed: () { _page = 1; _load(); }, icon: const Icon(Icons.search))),
      onChanged: (v) => _search = v.trim(), onSubmitted: (_) { _page = 1; _load(); }),
    const SizedBox(height: 12),
    if (_list(data['items']).isEmpty) const ABPanel(child: Text('محصولی پیدا نشد.')),
    ..._list(data['items']).map((p) => ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        if ('${p['image_url'] ?? ''}'.startsWith('https://')) ...[
          ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network('${p['image_url']}', width: 52, height: 52, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.inventory_2_outlined))),
          const SizedBox(width: 10),
        ],
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${p['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('SKU: ${p['sku']} · ${p['type']}', style: const TextStyle(color: ABTheme.quiet, fontSize: 12)),
        ])),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: Text('قیمت: ${_num(p['regular_price'])}', style: const TextStyle(fontWeight: FontWeight.w700))),
        Text('موجودی: ${p['stock_quantity'] ?? '—'}', style: const TextStyle(color: ABTheme.quiet)),
      ]),
      if (p['can_edit'] == true) Align(alignment: Alignment.centerLeft,
        child: TextButton.icon(onPressed: () => _editProduct(p), icon: const Icon(Icons.edit_outlined), label: const Text('ویرایش سریع'))),
      if (p['type'] == 'variable') Align(alignment: Alignment.centerLeft,
        child: TextButton.icon(onPressed: () => _variations(p), icon: const Icon(Icons.layers_outlined), label: const Text('نمایش تنوع‌ها'))),
    ]))),
    _pager(data),
  ]);

  Future<void> _variations(Map<String, dynamic> parent) async {
    try {
      final data = await widget.api.get('products/${parent['id']}/variations', {'page':'1','per_page':'30'});
      if (!mounted) return;
      final children = _list(data['items']);
      await showModalBottomSheet<void>(context: context, isScrollControlled: true,
        builder: (context) => SafeArea(child: Padding(padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('تنوع‌های ${parent['name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(height: 10),
            ConstrainedBox(constraints: const BoxConstraints(maxHeight: 430), child: ListView(
              shrinkWrap: true, children: children.map((p) => ListTile(
                title: Text('${p['attributes']}', maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text('قیمت: ${p['regular_price']} · موجودی: ${p['stock_quantity'] ?? '—'}'),
                trailing: p['can_edit'] == true ? IconButton(icon: const Icon(Icons.edit_outlined),
                  onPressed: () { Navigator.pop(context); _editProduct(p); }) : null,
              )).toList(),
            )),
            if ((data['pages'] ?? 1) > 1) const Text('برای مشاهده تمام تنوع‌ها از پنل وب استفاده کنید.'),
          ]))));
    } catch (e) { _error(e); }
  }

  Future<void> _editProduct(Map<String, dynamic> product) async {
    final isStock = product['manage_stock'] == true;
    final isPrice = ['simple', 'variation'].contains('${product['type']}');
    final selected = await showModalBottomSheet<String>(context: context, isScrollControlled: true,
      builder: (context) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(
        mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${product['name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          if (isStock) ListTile(title: const Text('ویرایش موجودی'), leading: const Icon(Icons.inventory_2_outlined), onTap: () => Navigator.pop(context, 'stock')),
          if (isPrice) ListTile(title: const Text('ویرایش قیمت عادی'), leading: const Icon(Icons.payments_outlined), onTap: () => Navigator.pop(context, 'price')),
          if (!isStock && !isPrice) const Text('ویرایش سریع برای این نوع محصول در دسترس نیست.'),
        ]))),
    );
    if (selected == null || !mounted) return;
    final stock = selected == 'stock';
    final oldValue = stock ? product['stock_quantity'] : product['regular_price'];
    final controller = TextEditingController(text: '$oldValue');
    final newValue = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: Text(stock ? 'موجودی جدید' : 'قیمت عادی جدید'),
      content: TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'مقدار جدید')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('ثبت با تأیید'))],
    ));
    controller.dispose();
    if (newValue == null) return;
    final stockValue = stock ? int.tryParse(newValue) : null;
    if ((stock && (stockValue == null || stockValue < 0 || stockValue > 100000000)) ||
        (!stock && !RegExp(r'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,4})?$').hasMatch(newValue))) {
      _error('مقدار معتبر وارد کنید.'); return;
    }
    final Object parsed = stock ? stockValue! : newValue;
    try {
      await widget.api.put('products/${product['id']}', stock
        ? {'stock_quantity':parsed, 'expected_stock': oldValue}
        : {'regular_price':parsed, 'expected_regular_price': oldValue});
      if (!mounted) return;
      _load();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تغییر محصول ذخیره شد.')));
    } catch (e) { _error(e); }
  }

  Widget _assistant(Map<String, dynamic> data) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const ABHeading('دستیار مدیریت', subtitle: 'تحلیل امن و مبتنی بر داده‌های نمونه؛ تحلیل مولد با رضایت صریح اختیاری است'),
    ..._list(data['items']).map((item) => ABPanel(child: ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(item['severity'] == 'warning' ? Icons.warning_amber_rounded : Icons.check_circle_outline_rounded, color: ABTheme.gold),
      title: Text('${item['title']}', style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('${item['summary']}', style: const TextStyle(height: 1.6)),
    ))),
    const SizedBox(height: 14),
    const Text('از دستیار بپرسید', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
    const SizedBox(height: 10),
    TextField(controller: _query, minLines: 2, maxLines: 3, maxLength: 240,
      decoration: const InputDecoration(hintText: 'مثلاً: محصولات کم‌موجودی را نمایش بده')),
    const SizedBox(height: 8),
    FilledButton.icon(onPressed: _asking ? null : _ask,
      icon: const Icon(Icons.auto_awesome_outlined), label: Text(_asking ? 'در حال بررسی…' : 'دریافت تحلیل')),
    if (_answer != null) ...[
      const SizedBox(height: 18),
      ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('${_answer!['title'] ?? 'نتیجه'}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8), Text('${_answer!['summary'] ?? ''}', style: const TextStyle(height: 1.7)),
        const SizedBox(height: 10),
        ..._list(_answer!['items']).map((v) => ListTile(dense: true, title: Text('${v['label']}'), subtitle: Text('${v['meta'] ?? ''}'))),
        const Divider(),
        Text('${_answer!['scope'] ?? ''}', style: const TextStyle(fontSize: 12, color: ABTheme.quiet, height: 1.6)),
      ])),
    ],
    const SizedBox(height: 18),
    ABPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Row(children: [Icon(Icons.psychology_alt_outlined, color: ABTheme.gold), SizedBox(width: 9),
        Expanded(child: Text('توضیح هوشمند گزارش با AI', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)))]),
      const SizedBox(height: 8),
      const Text('در صورت فعال بودن سرویس، خلاصه محدود گزارش بدون اطلاعات هویتی مشتری به ارائه‌دهنده خارجی ارسال می‌شود. قبل از هر درخواست باید تأیید کنید.',
        style: TextStyle(color: ABTheme.quiet, fontSize: 12, height: 1.8)),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: _aiAsking ? null : _askAi,
        icon: const Icon(Icons.auto_awesome_outlined),
        label: Text(_aiAsking ? 'در حال تحلیل…' : 'تحلیل با AI (با تأیید من)')),
      if (_aiConnected == false) const Padding(padding: EdgeInsets.only(top: 10),
        child: Text('اتصال AI روی سرور تنظیم نشده است؛ دستیار رایگان مبتنی بر قواعد همچنان فعال است.',
          style: TextStyle(color: ABTheme.quiet, fontSize: 12, height: 1.7))),
      if (_aiAnswer != null) ...[
        const SizedBox(height: 14),
        Text('${_aiAnswer!['explanation'] ?? ''}', style: const TextStyle(height: 1.9)),
        const SizedBox(height: 10),
        Text('${_aiAnswer!['disclaimer'] ?? ''}', style: const TextStyle(fontSize: 11, color: ABTheme.quiet, height: 1.6)),
      ],
    ])),
    const SizedBox(height: 22),
    const Text('برنامه اقدامات مدیریتی' , style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
    const SizedBox(height: 10),
    DropdownButtonFormField<String>(
      value: _planGoal,
      items: const [
        DropdownMenuItem(value: 'overview', child: Text('ارزیابی کلی فروشگاه')),
        DropdownMenuItem(value: 'fulfillment', child: Text('رسیدگی به سفارش‌ها')),
        DropdownMenuItem(value: 'restock', child: Text('تأمین موجودی')),
      ],
      onChanged: _planning ? null : (v) { if (v != null) setState(() => _planGoal = v); },
    ),
    const SizedBox(height: 10),
    OutlinedButton.icon(
      onPressed: _planning ? null : _buildPlan,
      icon: const Icon(Icons.fact_check_outlined),
      label: Text(_planning ? 'در حال بررسی…' : 'تهیه برنامه بدون تغییر خودکار'),
    ),
    if (_plan != null) ...[
      const SizedBox(height: 12),
      ..._list(_plan!['steps']).map((step) => ABPanel(child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.task_alt_rounded, color: ABTheme.gold),
        title: Text('${step['title'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${step['reason'] ?? ''}', style: const TextStyle(height: 1.7)),
      ))),
      Text('${_plan!['disclaimer'] ?? ''}',
        style: const TextStyle(fontSize: 11, color: ABTheme.quiet, height: 1.7)),
    ],
    const SizedBox(height: 10),
    Text('${data['scope'] ?? ''}', style: const TextStyle(fontSize: 11, color: ABTheme.quiet, height: 1.7)),
  ]);

  Future<void> _ask() async {
    final q = _query.text.trim();
    if (q.isEmpty || q.length > 240) return;
    setState(() => _asking = true);
    try {
      final answer = await widget.api.post('assistant/query', {'intent':'auto','query':q});
      if (mounted) setState(() => _answer = answer);
    } catch (e) { _error(e); }
    finally { if (mounted) setState(() => _asking = false); }
  }

  Future<void> _askAi() async {
    final query = _query.text.trim();
    if (query.isEmpty || query.length > 240) {
      _error('ابتدا سؤال خود را در بخش دستیار وارد کنید.');
      return;
    }
    if (_aiAsking) return;
    setState(() => _aiAsking = true);
    try {
      final status = await widget.api.get('ai/status');
      final enabled = status['enabled'] == true;
      if (mounted) setState(() => _aiConnected = enabled);
      if (!enabled) return;
      if (!mounted) return;
      final approved = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('تأیید ارسال خلاصه به AI'),
        content: const Text('فقط خلاصه محدود تحلیل فروشگاه و احتمالاً نام چند محصول، بدون اطلاعات هویتی مشتری و رمزهای اتصال، به سرویس خارجی ارسال می‌شود. هیچ تغییری در فروشگاه انجام نخواهد شد.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('موافقت و تحلیل')),
        ],
      ));
      if (approved != true) return;
      final answer = await widget.api.post('ai/explain', {'intent':'auto','query':query,'consent_external':true});
      if (mounted) setState(() => _aiAnswer = answer);
    } catch(e) { _error(e); }
    finally { if (mounted) setState(() => _aiAsking = false); }
  }

  Future<void> _buildPlan() async {
    setState(() => _planning = true);
    try {
      final result = await widget.api.post('assistant/plan', {'goal': _planGoal});
      if (mounted) setState(() => _plan = result);
    } catch (e) { _error(e); }
    finally { if (mounted) setState(() => _planning = false); }
  }

  Widget _notifications(Map<String, dynamic> data) {
    final rows = _list(data['items']);
    final unread = rows.where((item) => item['read'] == false).map((item) => item['id']).whereType<int>().take(30).toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const ABHeading('مرکز اعلان‌ها', subtitle: 'رویدادهای ثبت‌شده از داخل WooSuite Hub'),
      if (unread.isNotEmpty) Align(alignment: Alignment.centerLeft, child: TextButton.icon(
        onPressed: () async {
          try { await widget.api.post('notifications/read', {'ids':unread}); if (mounted) _load(); }
          catch (e) { _error(e); }
        },
        icon: const Icon(Icons.done_all_rounded), label: const Text('خوانده‌شدن اعلان‌های صفحه'))),
      if (rows.isEmpty) const ABPanel(child: Text('اعلان جدیدی ثبت نشده است.')),
      ...rows.map((item) => ABPanel(child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(item['severity'] == 'warning' ? Icons.warning_amber_rounded : Icons.notifications_outlined,
          color: item['read'] == true ? ABTheme.quiet : ABTheme.gold),
        title: Text(_eventTitle('${item['event']}'), style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${item['date'] ?? ''} · #${item['object_id'] ?? ''}'),
        trailing: item['read'] == true ? const Icon(Icons.done_all, color: ABTheme.quiet, size: 17) : const Icon(Icons.circle, color: ABTheme.gold, size: 10),
      ))),
      _pager(data),
    ]);
  }

  String _eventTitle(String key) => switch (key) {
    'inventory.low_stock' => 'هشدار کمبود موجودی',
    'order.status_changed' => 'تغییر وضعیت سفارش',
    'product.updated' => 'ویرایش محصول',
    _ => 'رویداد فروشگاه',
  };

  Widget _pager(Map<String, dynamic> data) {
    final totalPages = (data['pages'] as num?)?.toInt() ?? 1;
    if (totalPages <= 1) return const SizedBox(height: 12);
    return Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        OutlinedButton(onPressed: _page > 1 ? () { _page--; _load(); } : null, child: const Text('قبلی')),
        Text('صفحه ${_num(_page)} از ${_num(totalPages)}'),
        OutlinedButton(onPressed: _page < totalPages ? () { _page++; _load(); } : null, child: const Text('بعدی')),
      ]));
  }

  Widget _section(String title) => Padding(padding: const EdgeInsets.symmetric(vertical: 10),
    child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)));

  Widget _chip(String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(color: ABTheme.gold.withOpacity(.12), borderRadius: BorderRadius.circular(18)),
    child: Text(label, style: const TextStyle(color: ABTheme.black, fontSize: 11, fontWeight: FontWeight.w800)),
  );

  List<Map<String, dynamic>> _list(Object? rows) => rows is List
      ? rows.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
      : <Map<String, dynamic>>[];
}
