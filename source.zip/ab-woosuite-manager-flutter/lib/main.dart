import 'package:flutter/material.dart';
import 'core/api_client.dart';
import 'core/session_store.dart';
import 'screens/login_screen.dart';
import 'screens/home_shell.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const WooSuiteManager());
}

class WooSuiteManager extends StatefulWidget {
  const WooSuiteManager({super.key});
  @override
  State<WooSuiteManager> createState() => _WooSuiteManagerState();
}

class _WooSuiteManagerState extends State<WooSuiteManager> {
  final _store = SessionStore();
  WooSuiteApi? _api;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    WooSuiteApi? api;
    try {
      api = await _store.restore();
      if (api != null) await api.get('mobile/bootstrap');
    } catch (_) {
      api?.dispose();
      api = null;
    }
    if (!mounted) return;
    setState(() { _api = api; _loading = false; });
  }

  Future<void> _login(WooSuiteApi api) async {
    await _store.save(api);
    if (!mounted) return;
    setState(() => _api = api);
  }

  Future<void> _logout() async {
    await _store.clear();
    _api?.dispose();
    if (!mounted) return;
    setState(() => _api = null);
  }

  @override
  void dispose() { _api?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ABTheme.light,
    title: 'WooSuite Manager',
    locale: const Locale('fa'),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
    home: _loading
        ? const Scaffold(body: Center(child: CircularProgressIndicator()))
        : _api == null
            ? LoginScreen(onConnected: _login)
            : HomeShell(api: _api!, onLogout: _logout),
  );
}
