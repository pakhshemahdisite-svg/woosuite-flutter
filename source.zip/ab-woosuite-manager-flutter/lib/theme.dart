import 'package:flutter/material.dart';

class ABTheme {
  static const gold = Color(0xFFB79044);
  static const black = Color(0xFF17191D);
  static const canvas = Color(0xFFF7F7F4);
  static const quiet = Color(0xFF747A83);
  static const border = Color(0xFFE7E6E0);
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, surface: Colors.white, primary: black),
        appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: black, centerTitle: false, elevation: 0),
        filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
          backgroundColor: black, foregroundColor: Colors.white, minimumSize: const Size(0, 50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(borderSide: const BorderSide(color: border), borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: border), borderRadius: BorderRadius.circular(14))),
        dividerColor: border,
      );
}

class ABPanel extends StatelessWidget {
  const ABPanel({super.key, required this.child, this.padding = const EdgeInsets.all(18)});
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(
      side: const BorderSide(color: ABTheme.border), borderRadius: BorderRadius.circular(20)),
    child: Padding(padding: padding, child: child));
}

class ABHeading extends StatelessWidget {
  const ABHeading(this.title, {super.key, this.subtitle});
  final String title;
  final String? subtitle;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 16, top: 6),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: ABTheme.black)),
      if (subtitle != null) ...[const SizedBox(height: 7), Text(subtitle!, style: const TextStyle(color: ABTheme.quiet, height: 1.6))],
    ]),
  );
}
