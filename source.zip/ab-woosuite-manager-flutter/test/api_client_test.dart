import 'package:flutter_test/flutter_test.dart';
import 'package:ab_woosuite_manager/core/api_client.dart';

void main() {
  test('only HTTPS URLs can be used', () {
    expect(() => WooSuiteApi.parseSite('http://shop.test'), throwsA(isA<ApiException>()));
    expect(() => WooSuiteApi.parseSite('https://user:pass@shop.test'), throwsA(isA<ApiException>()));
    expect(() => WooSuiteApi.parseSite('https://shop.test/?key=x'), throwsA(isA<ApiException>()));
  });
  test('API retains WordPress subpath', () {
    final uri = WooSuiteApi.parseSite('https://shop.test/store/');
    final api = WooSuiteApi(site: uri, username: 'manager', appPassword: 'test app password');
    expect(api.endpoint('mobile/bootstrap').toString(), 'https://shop.test/store/wp-json/ab-woosuite/v1/mobile/bootstrap');
    expect(() => api.endpoint('../unsafe'), throwsA(isA<ApiException>()));
    api.dispose();
  });
}
