# AB WooSuite Manager — Flutter source v0.7.0

Requires WooSuite Hub v0.7.0+. New: a consent-per-request OpenAI-backed explanation of existing local reports, using `GET ai/status` and `POST ai/explain`. This is disabled until server-side `ABWSH_AI_ENABLED` and `ABWSH_AI_API_KEY` are configured. Credentials are never included in the Flutter source. The user must accept the disclosure dialog for each external request; the model cannot mutate WooCommerce data.

**Still source only:** Flutter SDK was not available during this iteration; `flutter analyze`, `flutter test`, iOS/Android compilation and actual device tests remain mandatory before release.

---

# AB WooSuite Manager — Flutter source v0.6.0

A Persian/RTL mobile manager client for **AB WooSuite Hub 0.6.0**. The source includes login, operational dashboard, paginated order/product lists, quick edits with optimistic guards and confirmation, variations (first 30), rules-based assistant, and a per-manager notification reader.

## New in 0.6.0

- Dedicated **Module Catalog** screen, reachable from the manager dashboard. Installed/active modules are distinguished from unreleased roadmap entries; it does **not** purchase, install or activate plugins.
- **Action Playbook** in the mobile assistant for overview, fulfillment or restock. Suggestions are deterministic, use bounded WooCommerce sample data, and never trigger write operations.
- Uses `GET modules/catalog` and `POST assistant/plan` with existing WordPress Application Password authorization; the backend enforces `manage_woocommerce` and a best-effort 12 requests/minute quota for action plans.

## Status

This is a **source-level MVP**. No signed APK, AAB or iOS IPA is included. Flutter/Dart SDK is not available in this build environment, so the UI has **not** been compiled, tested on device, or App Store reviewed. Run the commands below on an installed Flutter toolchain, resolve any dependency/API issues, and test on physical devices before release.

## Requirements

- A current stable Flutter SDK (recommended Flutter 3.29+ with Dart 3.7+) and Android Studio or Xcode.
- WordPress/WooCommerce with `ab-woosuite-hub` **v0.6.0+** active.
- Valid **HTTPS** with no certificate warnings. An application-specific WordPress Application Password for a dedicated account with `manage_woocommerce`; `edit_product` / `edit_shop_order` capabilities are additionally checked on mutations.
- Enable WordPress Application Passwords for the relevant user (in WordPress user profile). Never use the user's main WordPress login password.

## Build from sources

```bash
# In the ab-woosuite-manager-flutter/ directory:
flutter create --platforms=android,ios .
flutter pub get
flutter analyze
flutter test
flutter run
# Only after device integration tests / signing configuration:
flutter build apk --release
```

After generating Android files, confirm `android/app/src/main/AndroidManifest.xml` contains `<uses-permission android:name="android.permission.INTERNET"/>` immediately under `<manifest>` (outside `<application>`). Also set a unique Android `applicationId` / iOS bundle identifier, signing keys, privacy policy and application icon before public release. Do **not** embed service credentials in source, assets, build arguments or APK.

## Login sequence

1. Admin opens **WooSuite Pro > مرکز اپلیکیشن** to verify TLS and available routes.
2. Admin creates a named **WordPress Application Password** in Users > Profile, dedicated to one device.
3. On the app login screen, enter exact HTTPS WordPress site root, WordPress username and the *Application Password*, not main password.
4. App requests `GET /wp-json/ab-woosuite/v1/mobile/bootstrap`. It refuses incompatible `api_version` or HTTP error responses, then writes connection values using `flutter_secure_storage`.
5. Press logout to delete local credentials. If a device is stolen, **revoke its Application Password in WordPress**: local logout alone cannot revoke already compromised credentials.

## API contract

| Feature | Route | Method |
|---|---|---|
| Connection | `mobile/bootstrap` | GET |
| Profile | `mobile/profile` | GET |
| Scoped briefing | `mobile/briefing` | GET |
| Dashboard | `dashboard` | GET |
| Products | `products?page=1&per_page=15` | GET |
| Variations | `products/{parentId}/variations` | GET |
| Update product | `products/{productId}` | PUT |
| Orders | `orders?page=1&per_page=15` | GET |
| Update order status | `orders/{id}/status` | PUT |
| Rules assistant | `assistant/query` | POST |
| Module catalog | `modules/catalog` | GET |
| Action Playbook | `assistant/plan` | POST |
| Notices | `notifications?page=1` | GET |
| Mark notices read | `notifications/read` | POST |

The client never sends WooCommerce REST consumer secrets or Telegram tokens. Mobile authentication uses WordPress Application Passwords with an HTTP Basic Authorization header **only over HTTPS**; redirects are disabled, the route path is constrained, responses are bounded and the password resides in secure OS storage. The app must not use a WebView or mixed-content fallback for REST auth.

## Accurate scope and limits

- Dashboard sample is up to 30 recent orders and 100 recent main products. It is **not** total store revenue, profit, or warehouse analytics.
- Rules assistant **does not** use generative AI; no external model is contacted.
- Order updates support only the Hub quick-edit transitions (`on-hold -> processing`, `processing -> on-hold/completed`). WooCommerce may send its normal status emails.
- Product quick-edit operates on regular price **or** managed stock separately and rejects stale expected values with HTTP 409. Variation management displays up to the first 30 variations at this point.
- App notifications are read from WooSuite activity only, not FCM push notifications or full-store audit.
- `flutter_secure_storage` relies on native OS keychains; platform backup and device policy should be reviewed before publication. Deploy HTTPS endpoints with valid trusted TLS certificates.

## Manual acceptance checklist

1. Login succeeds with a shop-manager account and valid WordPress Application Password.
2. Login fails with invalid credentials, insufficient permissions, HTTP origin and invalid certificate.
3. Android/iOS app displays product names, variation attributes, orders and RTL without clipping.
4. Edit simple product price and stock; stale expected values return 409; sale-price restrictions respected.
5. Only authorized status transitions are displayed and an order change is confirmed before submission.
6. Notifications marked read persist for that manager and not other managers.
7. Kill/restart the app; session restored securely if still valid. Revoke Application Password in WordPress; requests become unauthorized.
8. Test network loss, timeouts, large error bodies and no redirects to different hosts.
9. Perform `flutter analyze`, `flutter test` and device smoke testing before signed distribution.

## License & dependency notes

This starter is intended to be integrated with the existing WooSuite commercial project. Review licenses of Flutter packages and the WordPress plugin before distribution. No font files, secrets, brand images or customer records are bundled.
